

        let dbConnection = new DbConnection();
        let dbContext = dbConnection.context;
        let error = document.getElementById("ds_Error");
        let FullName = document.getElementById("fullName");
        let RegistrationNumber = document.getElementById("registrationNumber");
        let attendanceArray = [];
let isSearch = false;

let attendanceService = {

    displayAttendanceSheet: function () {
        dbConnection.open(function () {
           
            let selectQuery = "select all from AttendanceSheet where AttendanceDate=@1";
            let todayDate = new Date().toLocaleDateString();
            dbContext.executeQueryReader(selectQuery, todayDate,(reader, error) => {
                if (reader != null) {
                    attendanceArray = reader.slice(0);
                    attendanceService.displayHtmlTable(reader);
                   
                }
            });
        });
    },

    signAttendance: function (htmlElement) {

       
            error.innerText = "Processing the Attendance Sheet";


            let date = new Date();
            const formData = new FormData(htmlElement);
        let findIndex = attendanceArray.findIndex(x => x.registrationNumber == formData.get("RegistrationNumber"));
        if (findIndex == -1 || attendanceArray.length == 0) {
                dbConnection.open(function () {
                let addQuery = "add FullName=@1, RegistrationNumber=@2, TimeIn=@3, TimeOut=@4, AttendanceDate=@5 into AttendanceSheet";
                dbContext.executeQuery(addQuery, formData.get("FullName"), formData.get("RegistrationNumber"), date.toLocaleTimeString(), date.toLocaleTimeString(), date.toLocaleDateString(), (done, _error) => {

                    if (done) {
                        error.innerText = formData.get("RegistrationNumber") + " " + " has Signed In Successfully";
                        window.location.href = url + "#ds_Error";
                    }
                    else {
                        error.innerText = _error;
                    }
                    window.location.href = url + "#ds_Error";

                });


                });

            }
            else {
                error.innerText = formData.get("RegistrationNumber") + " " + " Already Sign In";
            }

          

        FullName.value = '';
        RegistrationNumber.value = '';
        attendanceService.displayAttendanceSheet();
    },
    signOutAttendance: function (htmlElement) {
        error.innerText = "Processing the Attendance Sheet";
       
            let date = new Date();
            const formData = new FormData(htmlElement);
            let findIndex = attendanceArray.findIndex(x => x.registrationNumber == formData.get("RegistrationNumber") && x.timeIn == x.timeOut);
        if (findIndex != -1 || attendanceArray.length == 0) {
            dbConnection.open(function () {
                let modifyQuery = "modify TimeOut=@1, AttendanceDate=@2 from AttendanceSheet where RegistrationNumber=@3";
                dbContext.executeQuery(modifyQuery, date.toLocaleTimeString(), date.toLocaleDateString(), formData.get("RegistrationNumber"), (done, _error) => {
                    if (done) {
                        error.innerText = formData.get("RegistrationNumber") + " " + " has Signed Out Successfully";
                    }
                    else {
                        error.innerText = _error;
                    }
                    window.location.href = url + "#ds_Error";
                });

            });
            }
            else {
                error.innerText = formData.get("RegistrationNumber") + " " + " Already Sign Out";

            }

     
        RegistrationNumber.value = '';
        attendanceService.displayAttendanceSheet();
    },
    displayHtmlTable: function (reader) {
        let i = 1;
        if (reader.length > 0) {
            reader.sort(function (a, b) {
                const previousDate = new Date(a.attendanceDate + " " + a.timeOut).getTime();
                const currentDate = new Date(b.attendanceDate + " " + b.timeOut).getTime();
                return (currentDate - previousDate);

            }).forEach(function (value, index) {
                let tableRow = "<tr>"
                    + "<td>" + i + "</td>"
                    + "<td>" + value.fullName + "</td>" +
                    "<td>" + value.registrationNumber + "</td>" +
                    "<td>" + value.timeIn + "</td>"
                    + "<td>" + value.timeOut + "</td>" +
                    "<td>" + value.attendanceDate + "</td>" +

                    "</tr>";
                $("#attendanceTable").append(tableRow);
                i++;
                if (!isSearch) {
                    attendanceArray.push(value);
                }
            });
        }
        else {
            $("#attendanceTable").append("<td> No  Attendance sign today");
        }
    },
    searchAttendanceByDate: function () {
        $("#attendanceTable").html('');
        let _attendanceDate = document.getElementById("attendaceDate");
       
        let searchDate = new Date(_attendanceDate.value).toLocaleDateString();
        dbConnection.open(function () {
            let selectQuery = "select all from AttendanceSheet where AttendanceDate=@1";

            dbContext.executeQueryReader(selectQuery, searchDate, (reader, _error) => {
              
                attendanceService.displayHtmlTable(reader);
            });
        });
        isSearch = true;
    }

}

function signAttendance(htmlElement) {
    attendanceService.signAttendance(htmlElement);
           
        }

function signOutAttendance(htmlElement) {
    attendanceService.signOutAttendance(htmlElement);
        }

function searchAttendanceByDate() {
    attendanceService.searchAttendanceByDate();
}
window.onload = function () {
    attendanceService.displayAttendanceSheet();
}
      