
WEB template is a responsive design which can be used for desktop users. Users visiting website from desktop browsers can view WEB template



/*
A Design by W3Layouts
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
*/
----------------------------------
NOTE : FREQUENTLY ASKED QUESTIONS 
----------------------------------

1. What is W3layouts?

	W3layouts is initiative of AgileITs to provide free web designs which are cross device supported.

2. Is W3layouts Templates Really Free?

	Yes, all our templates free to use for both commercial and non-commercial, but you have provide a back link to w3layouts.com which is already included in footer design by w3layouts.com don’t edit or remove it.

3. I want to Help W3layouts, How can i?

	You can help w3layouts By
	1. Donate Some $’s, Any Amount your wish
	2. Contribute Design inventory like stock photos, Icons or PSD designs with full rights to w3layouts

4. I want to remove w3layouts.com back link from footer.

	We have two plans for that per template and unlimited.
	Donate us $10 per template or Donate $500 use all the templates removing backlinks

5. Is these templates work on iPhone, Android platforms, basic Mobiles like java and Symbian?

	Yes, w3layouts templates work with all mobiles. To, support all the devices we are providing three different versions of designs WEB, SMARTPHONE and MOBILE Template

6. What is Web Template?

	WEB template is a responsive design which can be used for desktop users. Users visiting website from desktop browsers can view WEB template

7. What is SMARTPHONE Template?

	Smartphone template is compatible with smart devices like IPhone, android, windows and devices which support touch, HTML5 and java script.
	In Smartphone templates we may have included some gallery scripts which work with java script like JQuery.

8. What is MOBILE Template?

	Mobile template is designed using wap 2.0 standards with xhtml. In Mobile templates we don’t use javascript where basic mobile browsers not compatible with javascript and HTML5.
	Mobile Template can be used for Java, Symbain and other basic mobile browsers.

9. When we have responsive WEB template why we need separate SMARTPHONE and MOBILE template?

	Responsive design is good for users having speed network connection (WIFI, 3G). Responsive design will load the whole HTML, CSS and images which are used for desktop design, users in slow data connection have to wait and spend lot of data, time and money to load page. To save users Money and load time we have to use separate design depending on device compatibility.

10. How to detect and load different design for different Devices?

	Just download our design package it includes PHP script which does the magic, it will load the design by detecting device compatibility.

11. Is design package a CMS?

	No, Template package contains mobile detection scripts which will detect mobile and load the design. You have to change data in HTML files available at WEB, SMARTPHONE and Mobile folders manually.

12. Do I need any database?

	No, it is not necessary.

13. I want only iPhone design.

	iPhone design is available below iPhone demo preview. Click download below iPhone preview unzip the file iPhone design HTML files available add your data and images your iPhone website is ready.

14. I want only Mobile design.

	Mobile design is available below Mobile demo preview. Click download below Mobile preview unzip the file Mobile design HTML files available add your data and images your Mobile website is ready.

15. Do you provide WordPress Themes?

	Yes, we are working on it. Check WordPressM.com

16. Under which license you are providing these templates?

	W3layouts templates are under Creative Commons Attribution 3.0 unported
