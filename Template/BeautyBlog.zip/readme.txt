Beauty Blog is a blog which base on Beauty and lifestyle. it helps in improving beauty company. 
