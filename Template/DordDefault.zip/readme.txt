 Dord stream is a CMS software which writting in asp.net core and paired with MSSql Server
    And also allow or help front end developer to work as full stack developer

