  DordStream is a software development tools that provide set of tools, Modules and Application to support the development of website and web application. DordStream is a Cross-Platform and Open Source Software
     
    DordStream Offers two mode of Development
     Website : DordStream will allow you to create a website from scratch without writing any backend code. just Html and CSS. such as blog and website 
   
     Web Application : DordStream will allow you to create or develop a web application with basic knowledge in C#. such as web software. e.g Amazon, Facebook, Attendance Sheet and so on
     
     
    